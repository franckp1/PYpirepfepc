from setuptools import setup, find_packages

setup(
    name="PYpirepfepc",
    version="0.4",
    license="MIT",
    description="Cuestionario para reforzar tus conocimientos de python estilo juego trivia",
    author="Franck Pérez C",
    packages=find_packages(),
    url="https://github.com/franckp1/PYpirepfepc/tree/franckp1-patch-1"

)
